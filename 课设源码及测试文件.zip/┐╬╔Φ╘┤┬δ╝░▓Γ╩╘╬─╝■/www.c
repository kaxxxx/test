#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h> 

#define SERVER_PORT 8080  //侦听端口地址

struct stat st;
static int debug = 1;
static char parent_path[] = ".";
char z00[] = "HTTP/1.0 200 OK\r\n";
char f0f[] = "HTTP/1.0 404 NOT FOUND\r\n";

int get_http_line(int clnt_sock, char * buf, int size);
int headers(int clnt_sock, FILE *resourse, const char *header);
void tailers(int clnt_sock, FILE *resourse); 
void not_found(int clnt_sock);
void do_http_response(int clnt_sock, const char *path);
void * do_http_request(void * pclnt_sock); 

int main(){
    //创建套接字
    int serv_sock = socket(AF_INET, SOCK_STREAM, 0);
    
    //将套接字和IP、端口绑定
    struct sockaddr_in serv_addr;
    
    bzero(&serv_addr, sizeof(serv_addr));  //清空地址
       
    serv_addr.sin_family = AF_INET;  //使用IPv4地址
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  //具体的IP地址
    serv_addr.sin_port = htons(SERVER_PORT);  //端口
    
    int re_flag=1;
    int re_len=sizeof(int);
    setsockopt(serv_sock,SOL_SOCKET,SO_REUSEADDR,&re_flag,re_len);     //实现端口复用
    bind(serv_sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));  //绑定地址
    
    
    //进入监听状态，等待用户发起请求
    listen(serv_sock, 20);
    
    printf("wait client connect...\n");
 
    
    int done = 1;   
    while (done){
	    //接收客户端请求
	    struct sockaddr_in clnt_addr;
	    socklen_t clnt_addr_size = sizeof(clnt_addr);
	    int clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_addr, &clnt_addr_size);
    	
    	char client_ip[64];
    	char buf[256];
    	
    	pthread_t p_id; 
    	int * pclnt_sock = NULL;
    	pclnt_sock = (int *)malloc (sizeof(int));
    	*pclnt_sock = clnt_sock;
    	
    	//打印客户端ip地址和端口号 
    	printf("client ip: %s\t port: %d\n", 
			inet_ntop(AF_INET, &clnt_addr.sin_addr.s_addr, client_ip, sizeof(client_ip)), 
			ntohs(clnt_addr.sin_port));
	//开启线程
		pthread_create(&p_id, NULL, do_http_request, (void *)pclnt_sock);
	}
	
	//关闭套接字
	close(serv_sock);
    return 0;
}

void * do_http_request(void * pclnt_sock){
	int len = 0;
	char buf[256];
	char method[16]; //请求方法
	char url[256];  //请求的文件、路径
	char path[260];  //请求的文件、路径
	int clnt_sock = *(int *)pclnt_sock;
	len = get_http_line(clnt_sock, buf, sizeof(buf));  //获取请求行request line
	if (len > 0){
		int i = 0, j = 0;
		
		//获取请求方法 
		while (buf[j] != ' ' && i < sizeof(method) - 1){
			method[i++] = buf[j++];
		}
		method[i] = '\0';
		if (debug) printf("request method: %s\n", method);
		
		if (strncasecmp(method, "GET", i) == 0){  //get请求 
			while (buf[j++] != ' ');
			
			i = 0;
			
			//获取请求url 
			while (buf[j] != ' ' && i < sizeof(url) - 1){
				url[i++] = buf[j++];
			}
			url[i] = '\0';
			if (debug) printf("request url: %s\n", url);
			
			//去掉请求参数 
			char *last = strchr(url, '?');
			if (last) *last = '\0';
			
			if (debug) printf("real request url: %s\n", url);
			
			//获取请求文件、路径 
			sprintf(path, "%s%s", parent_path, url); 
			if (debug) printf("request path: %s\n", path);
			
			//判断文件是否存在
			if (stat(path, &st) == -1){
				fprintf(stderr, "stat %s find failed. reason: %s\n", path, strerror(errno));
				not_found(clnt_sock);
			}else {
				if (S_ISDIR(st.st_mode)){
					strcat(path, "index.html");
				}
				do_http_response(clnt_sock, path);
			}
		}else{  //其他请求 (暂不处理)
			fprintf(stderr, "other request [%s]\n", method);
		}
		
		if (debug) printf("request body:\n%s\n", buf);
		
		do{
			len = get_http_line(clnt_sock, buf, sizeof(buf));
			if (debug) printf("%s\n", buf);
		}while (len > 0);
		
	}else{  //请求格式有问题，出错处理 
		fprintf(stderr, "request format error\n");
	} 
	
	//关闭套接字
	close(clnt_sock);
	//释放指针 
	if (pclnt_sock) free(pclnt_sock);
	pclnt_sock = 0;
	return NULL;
}


void do_http_response(int clnt_sock, const char *path){
	FILE *resourse = NULL;
	resourse = fopen(path, "r");
	
	if (resourse == NULL){
		fprintf(stderr, "stat %s open failed. reason: %s\n", path, strerror(errno));
		not_found(clnt_sock);
		return;
	}
	
	//定义HTTP响应状态行
	char *header = z00;
	if (strncasecmp(path, "./error.html", 12) == 0){
		header = f0f;
	}
	
	//发送头部
	if (headers(clnt_sock, resourse, header) == 0){
		//发送内容
		tailers(clnt_sock, resourse);
	}
	
	fclose(resourse);
}

int get_http_line(int clnt_sock, char * buf, int size){
	int cnt = 0;  //这一行数据的字符个数
	char ch = '\0';
	int len = 0;
	
	while (cnt < size - 1 && ch != '\n'){
		len = read(clnt_sock, &ch, 1);  //读取缓冲区的一个字符
		if (len == 1){
			if (ch == '\r'){
				continue;
			}else if (ch == '\n'){
				break;
			}
		}else if (len == -1){
			fprintf(stderr, "read failed\n");
			cnt = -1;
			break;
		}else {
			fprintf(stderr, "client close\n");
			cnt = -1;
			break;
		}
		buf[cnt++] = ch;
	}
	
	if (cnt >= 0){
		buf[cnt] = '\0';
	}
	
	return cnt;
}

void not_found(int clnt_sock){
	do_http_response(clnt_sock, "./error.html");
}


int headers(int clnt_sock, FILE *resourse, const char *header){
	struct stat st;
	int fileId = 0;
	fileId = fileno(resourse);  //获取已经打开的文件的文件描述符
	if (fstat(fileId, &st) == -1){  //文件已经打开但是访问文件出错
		fprintf(stderr, "inner error. reason: %s\n", strerror(errno));
		return -1;
	}
	
	char buf[1024] = {0};
	char temp[64];
	//状态行
	strcpy(buf, header);
	//消息报头
	strcat(buf, "Server: Martin Server\r\n");
	strcat(buf, "Content-Type: text/html\r\n");
	strcat(buf, "Connection: Close\r\n");
	
	int wc = st.st_size;  //正文大小
	sprintf(temp, "Content-Length: %d\r\n\r\n", wc);
	strcat(buf, temp);
	
	if (debug) printf("write:\n%s\n", buf);
	
	if(send(clnt_sock, buf, strlen(buf), 0) < 0){
		fprintf(stderr, "failed to send.reason:%s.buf:%s\n", strerror(errno), buf);
		return -1;
	}
	return 0;
}

void tailers(int clnt_sock, FILE *resourse){
	char buf[1024];
	do{     //边读边写
		fgets(buf, sizeof(buf), resourse);
	 	int len = write(clnt_sock, buf, strlen(buf));
	 	
	 	if (len < 0){
	 		fprintf(stderr, "send error, reason: %s\n", strerror(errno));
	 		break;
		}
	 	
	 	if (debug) printf("%s", buf);
	}while (!feof(resourse));
	if (debug) printf("\n");
}

